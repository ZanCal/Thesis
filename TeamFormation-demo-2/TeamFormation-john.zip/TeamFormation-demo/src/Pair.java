
public class Pair {
  public int first;
  public int second;
}
